package com.example.a2teste;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private ImageView homeView;
    private Button buttonAprov;
    private Button buttonExame;
    private Button buttonRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        buttonAprov = findViewById(R.id.buttonaprov);
        buttonExame = findViewById(R.id.buttonexame);
        buttonRegis = findViewById(R.id.buttonregis);


    }

    public void onButtonAprovclick(View view) {
        Intent intent = new Intent(this,Approved.class);
        startActivity(intent);
    }

    public void onExamButtonClick(View view) {
        Intent intent = new Intent(this,Exam.class);
        startActivity(intent);
    }

    public void onRegisterButtonClick(View view) {
        Intent intent = new Intent(this,Register.class);
        startActivity(intent);
    }
}
