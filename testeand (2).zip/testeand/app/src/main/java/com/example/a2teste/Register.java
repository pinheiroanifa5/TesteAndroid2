package com.example.a2teste;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    private EditText editTextname;
    private EditText editTexttest1;
    private EditText editTexttest2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // EditText
        editTextname = findViewById(R.id.editTextname);
        editTexttest1 = findViewById(R.id.editTexttest1);
        editTexttest2 = findViewById(R.id.editTexttest2);
    }

    public void onRegisterButtonClick(View view) {
        // textos inseridos
        String name = editTextname.getText().toString();
        String test1 = editTexttest1.getText().toString();
        String test2 = editTexttest2.getText().toString();


        String message = "Name: " + name + "\nTest 1: " + test1 + "\nTest 2: " + test2;
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


}
